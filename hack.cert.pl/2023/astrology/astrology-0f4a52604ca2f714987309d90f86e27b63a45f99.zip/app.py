import os
from astropy import units as u
from astropy.coordinates import SkyCoord
from astroquery.alma import Alma
from flask import Flask, render_template, request
from urllib.parse import urlparse

app = Flask(__name__, template_folder=".", static_folder="static")


@app.get('/')
def index():
    return render_template('index.html', headers=[])


@app.post('/')
def query():
    ra = float(request.form['ra'])
    dec = float(request.form['dec'])
    r = float(request.form['r'])
    archive = request.form['archive']
    region = SkyCoord(ra=ra * u.deg, dec=dec * u.deg, frame='icrs')
    return render_template('index.html', results=download_readmes(archive, r * u.deg, region))


def download_readmes(archive, r, region):
    alma = Alma()
    if archive:
        alma.dataarchive_url = archive
    result = alma.query_region(region, radius=r)
    info = alma.get_data_info(list(set(result['member_ous_uid'])))
    readmes = [url for url in info['access_url'] if 'README' in url]
    alma.download_files(readmes, savedir="static/downloads")
    return [os.path.basename(urlparse(r).path) for r in readmes]


app.run(host="0.0.0.0")
